'use strict';
/* Require modules */
var plugins = {
  fs: require('fs'),
  os: require('os'),
  path: require('path'),
  gulp: require('gulp'),
  del: require('del'),
  clc: require('cli-color'),
  tar: require('tar-fs'),
  argv: require('yargs').argv,
  request: require('request'),
  gutil: require('gulp-util'),
  coffee: require('gulp-coffee'),
  concat: require('gulp-concat'),
  cssmin: require('gulp-cssmin'),
  replace: require('gulp-replace'),
  linker: require('gulp-linker'),
  uglify: require('gulp-uglify'),
  gulpMerge: require('gulp-merge'),
  browserSync: require('browser-sync'),
  order: require('gulp-order'),
  runSequence: require('run-sequence'),
  chmod: require('gulp-chmod'),
  compress: require('compression'),
  less: require('gulp-less'),
  coffeelint: require('gulp-coffeelint'),
  jshint: require('gulp-jshint'),
  notify: require('gulp-notify'),
  babel: require('gulp-babel'),

  historyApiFallback: require('connect-history-api-fallback')
};

/* Get params */
var params = {
  env: ((env) => {
    if (['gdev', 'gqc', 'prdtesting', 'prd'].indexOf(env) < 0) {
      env = 'gdev';
    }
    return env;
  })(),
  isFrameworkDev: plugins.argv.f || false,
  isDebug: !(plugins.argv.r || false),
  isDev: plugins.argv.d,
  assets: JSON.parse(plugins.fs.readFileSync('assets.json', 'utf8')),
  jsConcatOption: {newLine: ';\n'},
  cssConcatOption: {newLine: '\n'}
};

/* Load tasks */
['task_assets', 'task_framework', 'task_modules', 'task_serve', 'task_watch']
  .forEach((taskFileName) =>
    require(`./gulp_tasks/${taskFileName}`).initTask(plugins.gulp, plugins, params)
);
var gulp = plugins.gulp;
/* Set the default task */
gulp.task('default', (callback) =>
    plugins.runSequence(
      ['clean'],
      ['assets', 'framework'],
      ['modules'],
      ['serve', 'watch'],
      callback
    )
);

/* Tasks */
gulp.task('clean', (callback) => plugins.del(['./dist/'], callback));

gulp.task('coffeelint', () => {
  var rules = {
    'max_line_length': {level: 'ignore'}
  }, module = plugins.argv.m;
  return gulp.src([`./src/modules/${module}/**/*.coffee`])
    .pipe(plugins.coffeelint(rules))
    .pipe(plugins.coffeelint.reporter('coffeelint-stylish'));
});

// ���JS���롣�÷��� gulp jshint -m <module name>
gulp.task('jshint', () => {
  let module = plugins.argv.m || 'app-common';
  return gulp.src([
    `./src/modules/${module}/**/*.js`,
    `!./src/modules/${module}/+(vendor*|libs*)/**`
  ])
    .pipe(plugins.jshint(''))
    .pipe(plugins.jshint.reporter('gulp-jshint-html-reporter', {
      filename: './dist/jshint-output.html',
      createMissingFolders: true
    }))
    .on('end', () => plugins.browserSync({
      port: 10086,
      server: {
        baseDir: './dist',
        index: 'jshint-output.html'
      }
    }));
});

//���汾�������÷��� gulp upgrade -m <module name>
gulp.task('upgrade', () => {
  let fs = plugins.fs,
    moduleName = plugins.argv.m || 'app-common';
  let onlineVersionCheckUrl = 'http://10.16.76.248:9011/V1.1/vendortype?format=json';
  var deleteDir = (folderPath) => {
    fs.readdirSync(folderPath).forEach((item) =>{
      let itemPath = plugins.path.join(folderPath, item),
        stat = fs.lstatSync(itemPath);
      if(stat.isDirectory()){
        deleteDir(itemPath);
      }else{
        fs.unlinkSync(itemPath);
      }
    });
    fs.rmdirSync(folderPath);
  };
  var getCurrentModuleVersion = (moduleName) => {
    let appFilePath = `./src/modules/${moduleName}/app.coffee`;
    if (!fs.existsSync(appFilePath)) {
      throw 'App file is not found.';
    }
    var fileContent = fs.readFileSync(appFilePath, 'utf8'),
      matchArray = fileContent.match(/[.]version[\s]*[=][\s]*['"]([^']+)['"]/gi);
    if (!matchArray || matchArray.length === 0) {
      throw 'App file does not contain the version information. ';
    }
    var version = matchArray[0].split('=')[1].replace(/['"\s]/g, '');
    console.log(plugins.clc.green(`module ${moduleName}'s local version is: ${version}`));
    return version;
  };
  var replaceModuleFolder = (moduleName, versionNo, moduleUrl) => {
    let modulePath = `./src/modules/${moduleName}`;
    plugins.request(moduleUrl, (err, res, data) => {
      if (err || res.statusCode !== 200) {
        console.log(plugins.clc.red('Download module failed.'));
        return;
      }
      let tarPath = plugins.path.join(plugins.os.tmpdir(), 'newkit_temp_module.tar');
      try {
        fs.renameSync(modulePath, `${modulePath}_old`);
        fs.writeFileSync(tarPath, data);
        fs.createReadStream(tarPath).pipe(plugins.tar.extract(modulePath));
        deleteDir(`${modulePath}_old`);
        console.log(plugins.clc.green(`${moduleName} upgrade to version ${versionNo} succeed.`));
      } catch (err) {
        console.log(err);
      }
    });
  };
  var hasNewVersion = (currentVersionNo, onlineVersionNo) => {
    let currentNoArr = currentVersionNo.split('.'),
      onlineNoArr = onlineVersionNo.split('.'),
      hasNewVersion = false;

    if (currentNoArr.length !== 3 && onlineNoArr.length !== 3) {
      throw 'Version No invalid.';
    }
    if (onlineNoArr[0] > currentNoArr[0]) {
      hasNewVersion = true;
    } else if (onlineNoArr[0] === currentNoArr[0]) {
      if (onlineNoArr[1] > currentNoArr[1]) {
        hasNewVersion = true;
      } else if (onlineNoArr[1] === currentNoArr[1]) {
        if (onlineNoArr[2] > currentNoArr[2]) {
          hasNewVersion = true;
        }
      }
    }
    return hasNewVersion;
  };
  //��ʼ������-���°汾
  var currentVersion = getCurrentModuleVersion(moduleName);
  plugins.request(onlineVersionCheckUrl, (err, res, data) => {
    var newVersionNo = JSON.parse(data),
      packageUrl = 'http://scmisbiztalk01:8051/app-common.tar';
    newVersionNo = '1.1.0';
    console.log(plugins.clc.green(`module ${moduleName}'s latest version is: ${newVersionNo}`));
    if (!hasNewVersion(currentVersion, newVersionNo)) {
      console.log(plugins.clc.green(`${moduleName} have no new version.`));
      return;
    }
    replaceModuleFolder(moduleName, newVersionNo, packageUrl);
  });
});