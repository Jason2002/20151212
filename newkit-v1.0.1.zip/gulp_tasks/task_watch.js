'use strict';
module.exports = {
  initTask: (gulp, plugins, params) => {
    gulp.task('watch', () => {
      let watcher = gulp.watch([
        'src/config/*.*',
        'src/modules/**/*.*',
        'src/index.html'
      ], {debounceDelay: 500});
      watcher.on('change', (event) => {
        let path = event.path;
        //排除异常情况
        if (path.indexOf('.') < 0 || path.indexOf('___jb_') > 0) {
          return;
        }
        gulp.src('./src/index.html')
          .pipe(plugins.notify(`${(new Date().toLocaleTimeString())}开始重新构建模块...`));
        let pathArr = path.split('\\'),
          moduleIdx = pathArr.indexOf('modules');
        let tasks = [];
        if (moduleIdx > 0 && pathArr.length > moduleIdx + 2) {
          tasks.push(`modules_${pathArr[moduleIdx + 1]}`);
        } else if (path.indexOf('\\framework\\') || path.indexOf('\\src\\index.html') || path.indexOf('\\config\\')) {
          tasks.push(`framework`);
        }
        return plugins.runSequence(tasks, ['bs-reload']);
      });
    });

    gulp.task('bs-reload', () => {
      plugins.browserSync.reload();
      return gulp.src('./src/index.html')
        .pipe(plugins.notify(`${(new Date().toLocaleTimeString())}重新构建模块成功!`));
    });
  }
};
