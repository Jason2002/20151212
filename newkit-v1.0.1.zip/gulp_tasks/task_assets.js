'use strict';
module.exports = {
  initTask: (gulp, plugins, params) => {
    let concat = plugins.concat,
      isDebug = params.isDebug,
      assets = params.assets;

    gulp.task('assets', (callback) =>
        plugins.runSequence(
          ['assets.js', 'assets.css', 'assets.fonts', 'assets.images', 'assets.staticFiles', 'assets.requireJs'],
          ['assets.notify'],
          callback
        )
    );

    gulp.task('assets.notify', () =>
        console.log(plugins.clc.green('Build assets successfully.'))
    );

    gulp.task('assets.js', () =>
        gulp.src(assets[isDebug ? 'assetsJs' : 'assetsJs.min'])
          .pipe(concat('assets.js', params.jsConcatOption))
          .pipe(gulp.dest('./dist/assets/js/'))
    );

    gulp.task('assets.css', () =>
        gulp.src(assets[isDebug ? 'assetsCss' : 'assetsCss.min'])
          .pipe(concat('assets.css', params.cssConcatOption))
          .pipe(gulp.dest('./dist/assets/css/'))
    );

    gulp.task('assets.fonts', () =>
        gulp.src(assets['assetsFonts'])
          .pipe(gulp.dest('./dist/assets/fonts/'))
    );

    gulp.task('assets.images', () =>
        gulp.src(assets['assetsCssImages'])
          .pipe(gulp.dest('./dist/assets/css/'))
    );

    gulp.task('assets.staticFiles', () =>
        gulp.src(assets['assetsStaticFiles'])
          .pipe(gulp.dest('./dist/assets/'))
    );

    gulp.task('assets.requireJs', () =>
        gulp.src(assets[isDebug ? 'assetsRequireJs' : 'assetsRequireJs.min'])
          .pipe(concat('require.js', params.jsConcatOption))
          .pipe(gulp.dest('./dist/assets/js/'))
    );
  }
};