'use strict';
module.exports = {
  initTask: (gulp, plugins, params) => {
    let replace = plugins.replace,
      uglify = plugins.uglify;

    let isDebug = params.isDebug,
      env = params.env;

    gulp.task('framework', (callback) =>
        plugins.runSequence(
          ['fw.copyFiles', 'fw.processConfig'],
          ['fw.cache'],
          ['fw.notify'],
          callback
        )
    );

    gulp.task('fw.notify', () =>
        console.log(plugins.clc.green('Build framework successfully.'))
    );

    gulp.task('fw.copyFiles', () =>
        gulp.src([
          './src/index.html',
          './src/favicon.ico',
          './src/framework*/img/ckeditor/**/*',
          './src/themes*/**/*.*'
        ]).pipe(plugins.chmod(777))
          .pipe(gulp.dest('./dist/'))
    );

    gulp.task('fw.processConfig', () => {
      let gulpStrem = gulp.src(['./src/config/config.js'])
        .pipe(plugins.chmod(777))
        .pipe(replace('placeHolder', env))
        .pipe(replace('NEG.debug = true;', 'NEG.debug = ' + isDebug + ';'));
      if (!isDebug) {
        gulpStrem = gulpStrem.pipe(uglify());
      }
      return gulpStrem.pipe(gulp.dest('./dist/config/'));
    });

    gulp.task('fw.cache', () => {
      var version = (new Date).valueOf() + '';
      return gulp.src('./dist/index.html')
        .pipe(replace('.js"></script>', '.js?v=' + version + '"></script>'))
        .pipe(replace('.css" />', '.css?v=' + version + '" />'))
        .pipe(gulp.dest('./dist'));
    });
  }
};