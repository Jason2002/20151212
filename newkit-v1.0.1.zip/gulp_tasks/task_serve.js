'use strict';
module.exports = {
  initTask: (gulp, plugins, params) =>
    gulp.task('serve', () =>
        plugins.browserSync({
          server: {
            baseDir: './dist'
          },
          middleware: [plugins.historyApiFallback(), plugins.compress()],
          ghostMode: false,
          port: 8888,
          files: []
        })
    )
};