'use strict';
module.exports = {
  initTask: (gulp, plugins, params) => {
    let coffee = plugins.coffee,
      concat = plugins.concat,
      gutil = plugins.gutil,
      cssmin = plugins.cssmin,
      less = plugins.less,
      gulpMerge = plugins.gulpMerge,
      uglify = plugins.uglify,
      chmod = plugins.chmod;

    let isDebug = params.isDebug,
      isDev = params.isDev;

    var moduleTasks = [];

    gulp.task('modules', (callback) =>
        plugins.runSequence(moduleTasks, ['modules.notify'], callback)
    );

    gulp.task('modules.notify', () => console.log(plugins.clc.green('Build modules successfully.')));

    plugins.fs.readdirSync('./src/modules/').forEach((moduleName) => {
      createBuildModuleTask(moduleName);
      return moduleTasks.push(`modules_${moduleName}`);
    });

    function createBuildModuleTask(moduleName) {
      let modulePath = `./src/modules/${moduleName}`;
      // JS 任务
      gulp.task(`modules_${moduleName}_js`, () => {
        var gulpStream = gulpMerge(
          gulp.src([`${modulePath}/vendor/**/*.js`])
          , gulp.src([`${modulePath}/**/*.coffee`, `!${modulePath}/libs/**/*.*`, `!${modulePath}/vendor/**/*.*`]).pipe(coffee({bare: true}).on('error', gutil.log))
          , gulp.src([`${modulePath}/i18n/*.js`, `${modulePath}/*.js`, `${modulePath}/**/*.js`, `!${modulePath}/libs/**/*.*`, `!${modulePath}/vendor/**/*.*`])
            .pipe(plugins.babel({presets: ['es2015']}))
          , gulp.src('./src/assets/empty/empty.js') // 通过一个一定有的空文件，保证能生成app.js

        ).pipe(chmod(777));
        if (!isDev) {
          gulpStream = gulpStream.pipe(concat('app.js', params.jsConcatOption));
        }

        if (!isDebug) {
          gulpStream = gulpStream.pipe(uglify());
        }
        return gulpStream.pipe(gulp.dest(`./dist/modules/${moduleName}/`))
      });
      // CSS 任务
      gulp.task(`modules_${moduleName}_css`, () => {
        var gulpStream = gulpMerge(
          gulp.src([`${modulePath}/vendor/**/*.css`])
          , gulp.src(`${modulePath}/**/*.less`).pipe(plugins.less())
          , gulp.src(`${modulePath}/**/*.css`)
          , gulp.src('./src/assets/empty/empty.css') //通过一个一定有的空文件，保证能生成app.css
        ).pipe(chmod(777));
        if (!isDev) {
          gulpStream = gulpStream.pipe(concat('app.css', params.cssConcatOption));
        }
        if (!isDebug) {
          gulpStream = gulpStream.pipe(cssmin());
        }
        return gulpStream.pipe(gulp.dest(`./dist/modules/${moduleName}/`));
      });

      gulp.task(`modules_${moduleName}_copyFiles`, () =>
          gulp.src([
            `./src/modules/${moduleName}/**`,
            `!./src/modules/${moduleName}/**/*.+(less|css|js|coffee)`,
            `./src/modules/${moduleName}/libs*/**/*`
          ])
            .pipe(chmod(777))
            .pipe(gulp.dest(`./dist/modules/${moduleName}`))
      );

      gulp.task(`modules_${moduleName}`, (callback) =>
          plugins.runSequence([`modules_${moduleName}_js`, `modules_${moduleName}_css`, `modules_${moduleName}_copyFiles`], callback)
      )
    }
  }
};